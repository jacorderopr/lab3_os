#include "functions.h"

int main() {
  pthread_t id1, id2;

  initscr();
  keypad(stdscr, TRUE);
  noecho();

  curs_set(0);

  ball_pos.x = 10;
  ball_pos.y = 20; 


  int key_stroke;
  int break_loop = 0;
  while (!break_loop) {
    key_stroke = getch();
    refresh();
    switch (key_stroke) {
      case KEY_LEFT:
        /* code */
        break;
      case 'f':
        /* code */
        break;
      case ENTER_NCURSES:
        // case KEY_ENTER:
        break_loop = 1;
        break;
    }
  }

pthread_create(&id1, NULL, UpdateBallPos, NULL);
pthread_create(&id2, NULL, UpdateCounter, NULL);


pthread_join(id1, NULL);
pthread_join(id2, NULL);

  getch();
  endwin();

  return 0;
}

